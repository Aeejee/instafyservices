<?php

namespace Stripe;

/**
 * Class BitcoinTransaction
 *
 * @package Stripe
 */
class BitcoinTransaction extends ApiResource
{
    const OBJECT_NAME = 'bitcoin_transaction';
}
